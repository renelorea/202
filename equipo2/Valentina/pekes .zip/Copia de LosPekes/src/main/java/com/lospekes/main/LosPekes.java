/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.lospekes.main;

import com.lospekes.vistas.LoginVista;

/**
 *
 * @author armando
 */
public class LosPekes {

    public static void main(String[] args) throws Exception{
        LoginVista login=new LoginVista();
        login.setVisible(true); 
    }
}
