import com.sun.jdi.connect.spi.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
/**
 * @author ediso
 */
public class conexion {
    //conexion local
    public static Connection conectar() {
        try {
            Connection cn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/sistemalogin", "root", "");
            return cn;
        } catch (SQLException e) {
            System.out.println("Error en la conexion local " + e);
        }
        return null;
    }
}