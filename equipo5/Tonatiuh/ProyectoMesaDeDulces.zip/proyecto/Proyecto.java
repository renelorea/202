/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.codifica.proyecto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Set;

public class Proyecto extends JFrame {

    CardLayout cardLayout;
    JPanel mainPanel;

    public Proyecto() {
        setTitle("LogIn");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(loginPanel(), "Login");
        mainPanel.add(principalPanel(), "Principal");
        mainPanel.add(altasBajasPanel(), "AltasBajas");
        mainPanel.add(modificacionesPanel(), "Modificaciones");
        mainPanel.add(consultasPanel(), "Consultas");
        mainPanel.add(inventarioPanel(), "Inventario");
 add(mainPanel);
        cardLayout.show(mainPanel, "Login");
    }

    private JPanel loginPanel() {
        JPanel panel = new JPanel();
        JTextField userField = new JTextField(15);
        JPasswordField passField = new JPasswordField(15);
        JButton loginButton = new JButton("Iniciar sesión");

        panel.add(new JLabel("Usuario:"));
        panel.add(userField);
        panel.add(new JLabel("Contraseña:"));
        panel.add(passField);
        panel.add(loginButton);

        loginButton.addActionListener(e -> cardLayout.show(mainPanel, "Principal"));
        return panel;
    }

    private JPanel principalPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnAltas = new JButton("Altas/Bajas de Usuarios");
        JButton btnModificaciones = new JButton("Modificaciones");
        JButton btnConsultas = new JButton("Consultas");
        JButton btnInventario = new JButton("Inventario");
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");
   btnAltas.addActionListener(e -> cardLayout.show(mainPanel, "AltasBajas"));
        btnModificaciones.addActionListener(e -> cardLayout.show(mainPanel, "Modificaciones"));
        btnConsultas.addActionListener(e -> cardLayout.show(mainPanel, "Consultas"));
        btnInventario.addActionListener(e -> cardLayout.show(mainPanel, "Inventario"));
        btnCerrarSesion.addActionListener(e -> cardLayout.show(mainPanel, "Login"));

        panel.add(btnAltas);
        panel.add(btnModificaciones);
        panel.add(btnConsultas);
        panel.add(btnInventario);
        panel.add(btnCerrarSesion);

        return panel;
    }

    private JPanel altasBajasPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columnas = {"ID", "Nombre", "Rol"};
        Object[][] datos = {
            {"1", "mafer", "Admin"},
            {"2", "vania", "jefe de almacen"}
        
        };

        JTable tabla = new JTable(new DefaultTableModel(datos, columnas));
        JScrollPane scrollPane = new JScrollPane(tabla);

        JButton btnRegresar = new JButton("Regresar");
  btnRegresar.addActionListener(e -> cardLayout.show(mainPanel, "Principal"));

        panel.add(new JLabel("Altas y Bajas de Usuarios", JLabel.CENTER), BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(btnRegresar, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel modificacionesPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextField idField = new JTextField();
        JTextField nombreField = new JTextField();
        JComboBox<String> rolBox = new JComboBox<>(new String[]{"Admin", "jefe de almacen"});

        form.add(new JLabel("ID Usuario:"));
        form.add(idField);
        form.add(new JLabel("Nuevo Nombre:"));
        form.add(nombreField);
        form.add(new JLabel("Nuevo Rol:"));
        form.add(rolBox);

        JButton btnGuardar = new JButton("Guardar Cambios");
        JButton btnRegresar = new JButton("Regresar");
 btnGuardar.addActionListener(e -> JOptionPane.showMessageDialog(this, "Cambios guardados."));
        btnRegresar.addActionListener(e -> cardLayout.show(mainPanel, "Principal"));

        JPanel botones = new JPanel();
        botones.add(btnGuardar);
        botones.add(btnRegresar);

        panel.add(new JLabel("Modificaciones de Usuarios", JLabel.CENTER), BorderLayout.NORTH);
        panel.add(form, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel consultasPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        String[] columnas = {"ID", "Nombre", "Rol"};
        Object[][] datos = {
            {"1", "mafer", "Admin"},
            {"2", "vania", "jefe de almacen"},
            {"3", "vane", "Usuario"}
        };

        JTable tabla = new JTable(new DefaultTableModel(datos, columnas));
        JScrollPane scrollPane = new JScrollPane(tabla);

 JButton btnRegresar = new JButton("Regresar");
        btnRegresar.addActionListener(e -> cardLayout.show(mainPanel, "Principal"));

        panel.add(new JLabel("Consultas de Usuarios", JLabel.CENTER), BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(btnRegresar, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel inventarioPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        String[] columnas = {"Nombre del Producto","ID del Producto","Precio", "Cantidad", "Precio Total"};
        Object[][] datos = {
            {"Lapiz","67839","$10", "25", "$250"},
            {"colores","73957","$180", "12", "$216"},
            {"plumones","93857","$16", "25", "$450"},
                 {"cuadernos","91037","$12", "12", "$120"},
                  {"dulces","40757","$10", "6", "$60"},
                   {"Chocolates","28905","$7", "63", "$441"},
                    {"impresiones","18391","$2", "23", "$46"}
        };

        JTable tabla = new JTable(new DefaultTableModel(datos, columnas));
        JScrollPane scrollPane = new JScrollPane(tabla);

        JButton btnRegresar = new JButton("Regresar");
        btnRegresar.addActionListener(e -> cardLayout.show(mainPanel, "Principal"));

        panel.add(new JLabel("Inventario", JLabel.CENTER), BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(btnRegresar, BorderLayout.SOUTH);
  return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Proyecto().setVisible(true));
    }

    private void add(String btnAgregar) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void actualizarusuarios() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void eliminarusuarios() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void agregarusuarios() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
