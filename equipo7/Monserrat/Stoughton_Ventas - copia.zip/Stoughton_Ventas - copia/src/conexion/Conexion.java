/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author monse
 */
public class Conexion {

  //  public static Connection conectar() {
//        try {
//            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost/sistemas_ventas","root","");
//            return cn;
//
//        } catch (SQLException e) {
//            System.out.println("Error en la conexion:" + e);
//        }
//        return null;

        public static Connection conectar(){
            try{

                try{
                    Class.forName("com.mysql.cj.jdbc.Driver");
                }catch(ClassNotFoundException ex){
                    System.out.println("error al registrar el driver de mysql:" + ex);

                }
                Connection connection=null;
                //databse connect
                //connectamos con la nase de datos
                connection=DriverManager.getConnection("jdbc:mysql://localhost/sistemas_ventas","root","");
                boolean valid=connection.isValid(50000);
                System.out.println(valid ? "TESTok": "TEST FAIL");
                return connection;
            }catch(java.sql.SQLException sqle){
                System.out.println("    ERROR:"+ sqle);
            }
            return null;
        }
        public static void main(String[]args){
            Conexion.conectar();
        }
    }
    

    

