
package controller;

import Dao.CustomersDao.*;
import Dao.CustomersDao;
import Models.Customers;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent; 
import java.awt.event.MouseListener;
import views.SystemViews;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class CustomersControllers implements ActionListener, MouseListener, KeyListener{

     //Encapsular variables
        private Customers customers;
        private CustomersDao customersDao;
        private SystemViews views;
        DefaultTableModel model = new DefaultTableModel();

        //Constructor
    public CustomersControllers(Customers customers, CustomersDao customersDao, SystemViews views) {
        this.customers = customers;
        this.customersDao = customersDao;
        this.views = views;
        
        //Boton Registrar cliente 
        this.views.btn_register_customer.addActionListener(this);
        //Tabla clientes
        this.views.customer_table.addMouseListener(this);
        //Buscador clientes
        this.views.txt_search_customer.addKeyListener(this);
        //Modificar btn
        this.views.btn_update_customer.addActionListener(this);
        //Eliminar
        this.views.btn_delete_customer.addActionListener(this);
        //Cancelar
        this.views.btn_cancel_customer.addActionListener(this);
    }
        
    @Override
    public void actionPerformed(ActionEvent e) {
    if(e.getSource()==views.btn_register_customer){
        if(views.txt_customer_ID.getText().equals("")
                || views.txt_customer_fullname.getText().equals("")
                ||views.txt_customer_address.getText().equals("")
                ||views.txt_customer_telephone.getText().equals("")
                ||views.txt_customer_email.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
            
        }else{
            customers.setId(Integer.parseInt(views.txt_customer_ID.getText().trim()));
            customers.setNombre_completo(views.txt_customer_fullname.getText().trim());
            customers.setDireccion(views.txt_customer_address.getText().trim());
            customers.setCorreo(views.txt_customer_email.getText().trim());
            customers.setTelefono(views.txt_customer_telephone.getText().trim());
            if(customersDao.registerCustomersQuery(customers)){
                CleanTable();
                listAllCustomers();
                cleanFields();
             JOptionPane.showMessageDialog(null, "Cliente registrado con exito");
            }else{
                JOptionPane.showMessageDialog(null, "Ha ocurrido un error al registrar cliente");
                
            }
        }
    }else if(e.getSource()==views.btn_update_customer){
        if(views.txt_customer_ID.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Selecciona una fila para continuar ");
        }else{
            if(views.txt_customer_ID.getText().equals("")
                || views.txt_customer_fullname.getText().equals("")
                ||views.txt_customer_address.getText().equals("")
                ||views.txt_customer_telephone.getText().equals("")
                ||views.txt_customer_email.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios");
            }else{
                customers.setId(Integer.parseInt(views.txt_customer_ID.getText().trim()));
                customers.setNombre_completo(views.txt_customer_fullname.getText().trim());
                customers.setDireccion(views.txt_customer_address.getText().trim());
                customers.setCorreo(views.txt_customer_email.getText().trim());
                customers.setTelefono(views.txt_customer_telephone.getText().trim());
                if(customersDao.updateCustomersQuery(customers)){
                    CleanTable();
                    cleanFields();
                    listAllCustomers();
                    views.btn_register_customer.setEnabled(true);
                    JOptionPane.showMessageDialog(null, "Datos del cliente modificados con exito");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un eroor al midificar cliente ");
                }
            }
        }
    }else if(e.getSource()==views.btn_delete_customer){
        int row = views.customer_table.getSelectedRow();
        if(row==1){
            JOptionPane.showMessageDialog(null, "Debes de selecionar un cliente para eliminar");
        }else{
        int id = Integer.parseInt(views.customer_table.getValueAt(row, 0).toString());
        int question = JOptionPane.showConfirmDialog(null, "En realidad quieres eliminar este cliente");
        if(question==0&& customersDao.deleteCustomersQuery(id)!=false){
            cleanFields();
            CleanTable();
            listAllCustomers();
            views.btn_register_customer.setEnabled(true);
            JOptionPane.showMessageDialog(null, "Cliente eliminado con exito!!!");
        }
    }
    }else if (e.getSource()==views.btn_cancel_customer){
        
    }
    }
    public void cleanFields(){
        views.txt_customer_ID.setText("");
        views.txt_customer_ID.setEditable(true);
        views.txt_customer_fullname.setText("");
        views. txt_customer_address.setText("");
        views.txt_customer_telephone.setText("");
        views.txt_customer_email.setText("");
    }
    
    //Listar clientes 
    public void listAllCustomers(){
       
 
        List<Customers>list = customersDao.listCustomersQuery(views.txt_search_customer.getText());
        model = (DefaultTableModel) views.customer_table.getModel();
        Object[]row = new Object[5];
        for(int i=0; i<list.size(); i++){
            row[0] = list.get(i).getId();
            row[1] = list.get(i).getNombre_completo();
                    row[2] = list.get(i).getDireccion();
                    row[3] = list.get(i).getTelefono();
                    row[4] = list.get(i).getCorreo();
                    model.addRow(row);
        }
        views.customer_table.setModel(model);
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource()==views.customer_table){
            int row = views.customer_table.rowAtPoint(e.getPoint());
            views.txt_customer_ID.setText(views.customer_table.getValueAt(row, 0).toString());
            views.txt_customer_fullname.setText(views.customer_table.getValueAt(row, 1).toString());
            views.txt_customer_address.setText(views.customer_table.getValueAt(row, 2).toString());
            views.txt_customer_telephone.setText(views.customer_table.getValueAt(row, 3).toString());
            views.txt_customer_email.setText(views.customer_table.getValueAt(row, 4).toString());
            
            views.btn_register_customer.setEnabled(false);
            views.txt_customer_ID.setEditable(false);
            
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource()==views.txt_search_customer){
            CleanTable();
            listAllCustomers();
            
        }
    }
    //Lipiar Tabla 
    public void CleanTable(){
         for (int i=0; i<model.getRowCount(); i++){
          model.removeRow(i);
          i=i-1;
         } 
    } 
}
