
package Models;

import java.sql.Connection;
import java.sql.DriverManager;


public class Connection_MySQL {
private String database_name="mi_familia_crochet";
private String user="root";
private String password="Password00";
private String url = "jdbc:mysql://localhost:3306/"+database_name;

Connection conn = null;

public Connection Getconnection(){
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn=DriverManager.getConnection(url,user,password); 
    }catch(Exception e){
        e.printStackTrace();
    }
    
    return conn;
}
}
