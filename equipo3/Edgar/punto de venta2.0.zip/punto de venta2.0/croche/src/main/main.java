
package main;

import views.Loginviews;


public class main {
    
     public static void main(String[] args) {
         
         Loginviews login = new Loginviews();
         login.setVisible(true);
    }
    
}
